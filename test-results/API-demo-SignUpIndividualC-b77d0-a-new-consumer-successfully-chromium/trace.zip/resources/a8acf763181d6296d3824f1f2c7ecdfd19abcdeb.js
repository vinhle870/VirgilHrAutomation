var a=(l=>(l[l.Manually=0]="Manually",l[l.Daily=1]="Daily",l[l.Monthly=2]="Monthly",l[l.Quarterly=3]="Quarterly",l[l.SetToGlobal=100]="SetToGlobal",l))(a||{});export{a as F};
