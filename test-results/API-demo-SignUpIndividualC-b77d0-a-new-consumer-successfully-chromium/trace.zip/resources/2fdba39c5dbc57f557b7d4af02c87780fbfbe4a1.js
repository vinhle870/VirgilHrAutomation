const e=(o,t)=>o.sort((n,c)=>{const r=n[t],s=c[t];return r<s?-1:r>s?1:0});export{e as s};
