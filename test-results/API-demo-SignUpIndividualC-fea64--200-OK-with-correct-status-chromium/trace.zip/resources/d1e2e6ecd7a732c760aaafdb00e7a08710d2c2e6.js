var n=(a=>(a[a.Business=1]="Business",a[a.Consultant=2]="Consultant",a))(n||{});export{n as B};
