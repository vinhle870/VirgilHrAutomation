import"./entry.2e4d2bd8.js";const i=""+globalThis.__publicAssetsURL("images/icon-drag-drop-fill.svg");export{i as _};
